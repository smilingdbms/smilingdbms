@echo off
echo ========================================================
echo  RecruitBase Pro — Create Test Users (Proper Auth)
echo  Creates 22 test users through Supabase Auth API
echo  Password for all: Test@123
echo  Takes 1-2 minutes (rate limit delays)
echo ========================================================
echo.

set PRJ=C:\Users\Pravin\OneDrive\Desktop\DBMS Folder\smilingdbms_project\smilingdbms

echo Step 1: Installing Supabase JS (if needed)...
cd /d "%PRJ%"
call npm list @supabase/supabase-js >nul 2>&1
if errorlevel 1 (
  echo Installing @supabase/supabase-js...
  call npm install @supabase/supabase-js
)

echo.
echo Step 2: Creating test users...
node "%~dp0create_test_users.js"

echo.
pause
