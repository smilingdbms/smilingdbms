const { createClient } = require('@supabase/supabase-js');

// Read Supabase credentials from project
const fs = require('fs');
const PRJ = String.raw`C:\Users\Pravin\OneDrive\Desktop\DBMS Folder\smilingdbms_project\smilingdbms`;

// Try to read supabase config from project
let SUPABASE_URL = '';
let SUPABASE_ANON_KEY = '';

const possibleFiles = [
  PRJ + String.raw`\src\lib\supabase.ts`,
  PRJ + String.raw`\src\lib\supabaseClient.ts`,
  PRJ + String.raw`\.env.local`,
  PRJ + String.raw`\.env`,
];

for (const f of possibleFiles) {
  if (fs.existsSync(f)) {
    const content = fs.readFileSync(f, 'utf8');
    const urlMatch = content.match(/https:\/\/[a-zA-Z0-9]+\.supabase\.co/);
    const keyMatch = content.match(/eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
    if (urlMatch) SUPABASE_URL = urlMatch[0];
    if (keyMatch) SUPABASE_ANON_KEY = keyMatch[0];
    if (SUPABASE_URL && SUPABASE_ANON_KEY) break;
  }
}

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.log('ERROR: Could not find Supabase credentials in project files.');
  console.log('Found URL:', SUPABASE_URL || 'NOT FOUND');
  console.log('Found Key:', SUPABASE_ANON_KEY ? 'FOUND' : 'NOT FOUND');
  process.exit(1);
}

console.log('='.repeat(56));
console.log(' RecruitBase Pro — Create Test Users (Proper Auth)');
console.log(' URL:', SUPABASE_URL);
console.log('='.repeat(56));

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const TEST_USERS = [
  // Lucky Consultancy Team
  { email: 'lucky.owner@test.com', password: 'Test@123', name: 'Rajesh Kumar', role: 'account_owner', userType: 'account_owner', companyId: 'aaaa1111-1111-1111-1111-111111111111', companyName: 'Lucky Consultancy', companyCode: 'LUCK1234', mobile: '9876500001', designation: 'Director', city: 'Mumbai' },
  { email: 'lucky.tl@test.com', password: 'Test@123', name: 'Priya Sharma', role: 'team_leader', userType: 'company_member', companyId: 'aaaa1111-1111-1111-1111-111111111111', companyName: 'Lucky Consultancy', companyCode: 'LUCK1234', mobile: '9876500002', designation: 'Team Leader', city: 'Mumbai' },
  { email: 'lucky.sr@test.com', password: 'Test@123', name: 'Amit Verma', role: 'sr_recruiter', userType: 'company_member', companyId: 'aaaa1111-1111-1111-1111-111111111111', companyName: 'Lucky Consultancy', companyCode: 'LUCK1234', mobile: '9876500003', designation: 'Sr. Recruiter', city: 'Delhi' },
  { email: 'lucky.rec@test.com', password: 'Test@123', name: 'Neha Patel', role: 'recruiter', userType: 'company_member', companyId: 'aaaa1111-1111-1111-1111-111111111111', companyName: 'Lucky Consultancy', companyCode: 'LUCK1234', mobile: '9876500004', designation: 'Recruiter', city: 'Mumbai' },
  { email: 'lucky.bd@test.com', password: 'Test@123', name: 'Vikram Singh', role: 'bd', userType: 'company_member', companyId: 'aaaa1111-1111-1111-1111-111111111111', companyName: 'Lucky Consultancy', companyCode: 'LUCK1234', mobile: '9876500005', designation: 'BD Executive', city: 'Pune' },

  // TechHire Solutions Team
  { email: 'tech.owner@test.com', password: 'Test@123', name: 'Sunita Reddy', role: 'account_owner', userType: 'account_owner', companyId: 'bbbb2222-2222-2222-2222-222222222222', companyName: 'TechHire Solutions', companyCode: 'TECH5678', mobile: '9876600001', designation: 'CEO', city: 'Hyderabad' },
  { email: 'tech.tl@test.com', password: 'Test@123', name: 'Deepak Mehta', role: 'team_leader', userType: 'company_member', companyId: 'bbbb2222-2222-2222-2222-222222222222', companyName: 'TechHire Solutions', companyCode: 'TECH5678', mobile: '9876600002', designation: 'Team Lead', city: 'Bangalore' },
  { email: 'tech.sr@test.com', password: 'Test@123', name: 'Kavita Joshi', role: 'sr_recruiter', userType: 'company_member', companyId: 'bbbb2222-2222-2222-2222-222222222222', companyName: 'TechHire Solutions', companyCode: 'TECH5678', mobile: '9876600003', designation: 'Sr. Recruiter', city: 'Bangalore' },
  { email: 'tech.rec@test.com', password: 'Test@123', name: 'Rohit Gupta', role: 'recruiter', userType: 'company_member', companyId: 'bbbb2222-2222-2222-2222-222222222222', companyName: 'TechHire Solutions', companyCode: 'TECH5678', mobile: '9876600004', designation: 'Recruiter', city: 'Hyderabad' },
  { email: 'tech.bd@test.com', password: 'Test@123', name: 'Meera Iyer', role: 'bd', userType: 'company_member', companyId: 'bbbb2222-2222-2222-2222-222222222222', companyName: 'TechHire Solutions', companyCode: 'TECH5678', mobile: '9876600005', designation: 'BD Manager', city: 'Chennai' },

  // Job Seekers
  { email: 'js.rahul@test.com', password: 'Test@123', name: 'Rahul Sharma', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700001', designation: 'Software Developer', city: 'Mumbai' },
  { email: 'js.nisha@test.com', password: 'Test@123', name: 'Nisha Roy', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700002', designation: 'Billing Executive', city: 'Delhi' },
  { email: 'js.akshay@test.com', password: 'Test@123', name: 'Akshay Kumar', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700003', designation: 'Sales Manager', city: 'Mumbai' },
  { email: 'js.pooja@test.com', password: 'Test@123', name: 'Pooja Desai', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700004', designation: 'HR Executive', city: 'Pune' },
  { email: 'js.arjun@test.com', password: 'Test@123', name: 'Arjun Nair', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700005', designation: 'React Developer', city: 'Bangalore' },
  { email: 'js.sneha@test.com', password: 'Test@123', name: 'Sneha Kapoor', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700006', designation: 'Marketing Manager', city: 'Delhi' },
  { email: 'js.vivek@test.com', password: 'Test@123', name: 'Vivek Pandey', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700007', designation: 'Accountant', city: 'Lucknow' },
  { email: 'js.anjali@test.com', password: 'Test@123', name: 'Anjali Mishra', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700008', designation: 'Content Writer', city: 'Mumbai' },
  { email: 'js.karan@test.com', password: 'Test@123', name: 'Karan Malhotra', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700009', designation: 'Business Analyst', city: 'Gurgaon' },
  { email: 'js.divya@test.com', password: 'Test@123', name: 'Divya Saxena', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700010', designation: 'Graphic Designer', city: 'Jaipur' },
  { email: 'js.manish@test.com', password: 'Test@123', name: 'Manish Tiwari', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700011', designation: 'Data Analyst', city: 'Hyderabad' },
  { email: 'js.priya@test.com', password: 'Test@123', name: 'Priya Agarwal', role: 'job_seeker', userType: 'job_seeker', mobile: '9877700012', designation: 'Full Stack Developer', city: 'Bangalore' },
];

async function createAllUsers() {
  let success = 0;
  let failed = 0;
  let skipped = 0;

  for (const u of TEST_USERS) {
    process.stdout.write(`Creating ${u.email}... `);

    // Step 1: Sign up through Supabase Auth API (proper way)
    const { data, error } = await supabase.auth.signUp({
      email: u.email,
      password: u.password,
      options: {
        data: { full_name: u.name }
      }
    });

    if (error) {
      if (error.message.includes('already') || error.message.includes('exists')) {
        console.log('already exists — updating app_users');
        // User exists in auth, just ensure app_users is correct
        const { data: existing } = await supabase.auth.signInWithPassword({
          email: u.email,
          password: u.password,
        });
        if (existing?.user) {
          await createAppUser(existing.user.id, u);
          await supabase.auth.signOut();
          skipped++;
        } else {
          console.log('SKIP — cannot login either');
          skipped++;
        }
        continue;
      }
      if (error.message.includes('rate') || error.message.includes('too many')) {
        console.log('RATE LIMITED — waiting 60 seconds...');
        await sleep(60000);
        // Retry
        const { data: retry, error: retryErr } = await supabase.auth.signUp({
          email: u.email,
          password: u.password,
          options: { data: { full_name: u.name } }
        });
        if (retryErr) {
          console.log('FAILED after retry: ' + retryErr.message);
          failed++;
          continue;
        }
        if (retry?.user) {
          await createAppUser(retry.user.id, u);
          await supabase.auth.signOut();
          success++;
          continue;
        }
      }
      console.log('FAILED: ' + error.message);
      failed++;
      continue;
    }

    if (data?.user) {
      await createAppUser(data.user.id, u);
      await supabase.auth.signOut();
      success++;
      console.log('OK');
    } else {
      console.log('FAILED: no user returned');
      failed++;
    }

    // Small delay to avoid rate limiting
    await sleep(1500);
  }

  console.log('\n' + '='.repeat(56));
  console.log(` Results: ${success} created, ${skipped} skipped, ${failed} failed`);
  console.log('='.repeat(56));
}

async function createAppUser(uid, u) {
  try {
    const { error } = await supabase.rpc('signup_user', {
      p_user_id: uid,
      p_email: u.email,
      p_full_name: u.name,
      p_mobile: u.mobile || null,
      p_role: u.role,
      p_title: u.designation || '',
      p_user_type: u.userType,
      p_company_id: u.companyId || null,
      p_company_name: u.companyName || null,
      p_company_code: u.companyCode || null,
      p_is_independent: false,
      p_status: 'active',
    });
    if (error) console.log('  app_users error: ' + error.message);
  } catch (e) {
    console.log('  app_users error: ' + e.message);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

createAllUsers().catch(e => console.log('Error:', e.message));
